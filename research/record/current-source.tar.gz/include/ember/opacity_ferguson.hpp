#pragma once
#include "ember/opacity_table.hpp"

namespace ember {
// Fixed-Z table; errors at every edge. See data/opacity/README.md for coverage.
class FergusonOpacity final : public TabulatedOpacity {
public:
  explicit FergusonOpacity(const std::filesystem::path& file)
      : TabulatedOpacity(file, "Ferguson+2005 (GS98)") {}
};
} // namespace ember
