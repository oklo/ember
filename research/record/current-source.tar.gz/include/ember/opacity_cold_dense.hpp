#pragma once
#include "ember/opacity_table.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace ember {

// Optional computed dense-gas table for a nearly metal-free H envelope.
// Input abundances are elemental atomic-mass fractions; place ElementalOpacity
// outside this join. The source remains an approximation to nonideal chemistry.
class ColdDenseOpacity final : public Opacity {
public:
  ColdDenseOpacity(const Opacity& original,const std::filesystem::path& table,double scale=1,
      const Opacity* atomic=nullptr)
      :original_(original),dense_(table,"cold dense gas",TabulatedOpacity::DensityAxis::logRho,
          AbundanceBasis::baryon_mass),scale_(scale),atomic_(atomic) {
    if(original.includes_conduction() || dense_.metallicity()!=0 || !std::isfinite(scale)
        || scale<.1 || scale>10 || (atomic && atomic->includes_conduction()))
      throw std::invalid_argument("ColdDenseOpacity: radiative zero-metal source and scale .1–10 required");
  }
  OpacityState eval(double T,double rho,const Composition& c) const override {
    if(!(T>0 && rho>0) || !std::isfinite(T+rho))
      throw std::domain_error("ColdDenseOpacity: invalid temperature or density");
    // The atomic family is supported above 23.21 kK and the original provider
    // finishes its low/atomic join at 29.51 kK. High log R must not select the
    // molecular table beyond its 30 kK ceiling. The optional atomic provider
    // supplies the overlap without consulting the low-temperature log-R table.
    if(atomic_ && T>=30000)return original_.eval(T,rho,c);
    const double Z=c.Z();
    // Return over 17.5–20 kK only where the original log R <= 6 table
    // is supported. At higher density retain the computed source, which
    // still enforces its own temperature and density limits. Every source with
    // nonzero weight must support the query.
    // Below 3500 K the original (AESOPUS) table ends at log R = 6, while cool
    // envelopes reach log R ~ 6.4. Complete the density join to the computed
    // source by log R = 5.98 at every T >= 3000 K (e), so the original is read
    // only where it is supported; unchanged for log R <= 5.9.
    const auto lo=step((T-3000)/500),hi=step((20000-T)/2500);
    const auto x=step((c.X[0]-.98)/.005),z=step((1e-10-Z)/(1e-10-1e-12));
    const double ln10=std::log(10.),logR=std::log10(rho)-3*(std::log10(T)-6);
    const auto d=step((logR-5.6)/.3),e=step((logR-5.9)/.08);
    const double hot=hi.value+(1-hi.value)*e.value;
    const double outer=hot*x.value*z.value;
    if(outer==0)return original_.eval(T,rho,c);
    const double m=lo.value+(1-lo.value)*e.value;
    const double w=outer*d.value*m;
    if(w==0)return original_.eval(T,rho,c);
    if(c.basis!=AbundanceBasis::atomic_mass || c.X[1]!=0 || c[Species::H2]!=0)
      throw std::domain_error("ColdDenseOpacity: elemental atomic-mass input required");
    // SYNSPEC uses integer H/He masses. Preserve the number densities and
    // extinction per length when converting the elemental input to that basis.
    // The negligible metals are represented by helium at fixed input H.
    constexpr double h=1/nuclides[0].A,he=4/nuclides[2].A,ds=h-he;
    const double s=c.X[0]*h+(1-c.X[0])*he;
    Composition source;source.basis=AbundanceBasis::baryon_mass;
    source.X[0]=c.X[0]*h/s;source.X[2]=1-source.X[0];
    auto b=dense_.eval(T,rho*s,source);
    b.dlnk_dX=b.dlnk_dX*(h-source.X[0]*ds)/s+(1+b.dlnk_dlnRho)*ds/s;
    b.kappa*=scale_*s;b.dlnk_dZ=0;
    const auto q=atomic_?step((T-26000)/4000):Weight{0,0};
    if(w==1 && q.value==0)return b;
    // Derivatives of w = outer d m in ln T (log R moves as -3 log T), ln rho, X and Z.
    const double dd_lnrho=d.derivative/(.3*ln10),de_lnrho=e.derivative/(.08*ln10);
    const double dm_lnT=T*lo.derivative/500*(1-e.value)-3*(1-lo.value)*de_lnrho;
    const double dm_lnrho=(1-lo.value)*de_lnrho;
    const double dh_lnT=-T*hi.derivative/2500*(1-e.value)-3*(1-hi.value)*de_lnrho;
    const double dh_lnrho=(1-hi.value)*de_lnrho;
    const double dwT=outer*(-3*dd_lnrho*m+d.value*dm_lnT)
        +x.value*z.value*d.value*m*dh_lnT;
    const double dwR=outer*(dd_lnrho*m+d.value*dm_lnrho)
        +x.value*z.value*d.value*m*dh_lnrho;
    const double dwX=d.value*m*hot*z.value*x.derivative/.005;
    const double dwZ=-d.value*m*hot*x.value*z.derivative/(1e-10-1e-12);
    if(q.value==0) {
      const auto a=original_.eval(T,rho,c);
      const double delta=std::log(b.kappa/a.kappa);
      return {std::exp((1-w)*std::log(a.kappa)+w*std::log(b.kappa)),
          (1-w)*a.dlnk_dlnT+w*b.dlnk_dlnT+dwT*delta,
          (1-w)*a.dlnk_dlnRho+w*b.dlnk_dlnRho+dwR*delta,
          (1-w)*a.dlnk_dX+w*b.dlnk_dX+dwX*delta,
          (1-w)*a.dlnk_dZ+dwZ*delta};
    }
    // Three log-opacity weights: original 1-w, gas w(1-q), atomic wq.
    // Evaluate a source only when its weight is nonzero; every such source
    // still enforces its own support. q and w have zero endpoint derivatives.
    const double dqT=T*q.derivative/4000;
    OpacityState result{0,0,0,0,0};
    const auto accumulate=[&](const OpacityState& s,double weight,
        double dT,double dR,double dX,double dZ) {
      const double l=std::log(s.kappa);
      result.kappa+=weight*l;
      result.dlnk_dlnT+=weight*s.dlnk_dlnT+dT*l;
      result.dlnk_dlnRho+=weight*s.dlnk_dlnRho+dR*l;
      result.dlnk_dX+=weight*s.dlnk_dX+dX*l;
      result.dlnk_dZ+=weight*s.dlnk_dZ+dZ*l;
    };
    if(w<1)accumulate(original_.eval(T,rho,c),1-w,-dwT,-dwR,-dwX,-dwZ);
    accumulate(b,w*(1-q.value),dwT*(1-q.value)-w*dqT,
        dwR*(1-q.value),dwX*(1-q.value),dwZ*(1-q.value));
    if(q.value>0)accumulate(atomic_->eval(T,rho,c),w*q.value,dwT*q.value+w*dqT,
        dwR*q.value,dwX*q.value,dwZ*q.value);
    result.kappa=std::exp(result.kappa);
    return result;
  }
  std::optional<DensityRange> density_range(double T,const Composition& c) const override {
    if(c.X[0]<=.98 || c.Z()>=1e-10)
      return original_.density_range(T,c);
    // The union depends on both join weights and each source's stencil.
    // eval enforces both domains wherever their weights are nonzero.
    return std::nullopt;
  }
  const char* name() const override {return "radiative opacity with cold dense-gas source";}
private:
  struct Weight {double value,derivative;};
  static Weight step(double u) {
    if(u<=0)return {0,0};
    if(u>=1)return {1,0};
    return {u*u*u*(10+u*(-15+6*u)),30*u*u*(1-u)*(1-u)};
  }
  const Opacity& original_;
  TabulatedOpacity dense_;
  double scale_;
  const Opacity* atomic_;
};
} // namespace ember
