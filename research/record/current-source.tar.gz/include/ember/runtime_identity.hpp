#pragma once
#include "ember/evolution_checkpoint.hpp"
#include "ember/atmosphere_hydrogen_envelope.hpp"

namespace ember::driver {

// File locations are provenance, not physics. Bind each input's role and
// family coordinates to its bytes so a relocated dataset remains restartable.
class RuntimeIdentity {
  std::map<fs::path,std::string> files_;
public:
  Identities values{{"identity_schema","ember-lifetime-inputs-v1"}};

  void file(const std::string& role,const fs::path& path) {
    const auto canonical=fs::canonical(path);
    auto found=files_.find(canonical);
    if(found==files_.end())found=files_.emplace(canonical,file_identity(canonical)).first;
    values[role]=found->second;
  }

  void number(const std::string& role,double value) {
    if(!std::isfinite(value))throw std::invalid_argument("nonfinite runtime identity: "+role);
    std::ostringstream text;text.imbue(std::locale::classic());
    text<<std::setprecision(std::numeric_limits<double>::max_digits10)<<value;
    values[role]=text.str();
  }

  void metal_atmosphere_chain(const std::string& role,const fs::path& path) {
    std::ifstream in(path);std::string magic,name;unsigned version{},count{};
    in>>magic>>version;
    if(!in || version!=1)throw std::runtime_error("invalid metal-atmosphere identity format");
    if(magic=="EMBER_METAL_ATMOSPHERE_RESPONSE") {file(role+".response",path);return;}
    if(magic!="EMBER_METAL_ATMOSPHERE_CHAIN" || !(in>>count) || count<1 || count>16)
      throw std::runtime_error("invalid metal-atmosphere identity chain");
    values[role+".format"]=magic+" "+std::to_string(version);
    number(role+".size",count);
    for(unsigned i=0;i<count;++i) {
      const auto interval=role+".interval."+std::to_string(i);
      number(interval+".reference_Z",read_representable_double(in));
      if(!(in>>std::quoted(name)) || name.empty())throw std::runtime_error("missing metal-atmosphere response");
      file(interval+".response",path.parent_path()/name);
    }
    if(in>>name)throw std::runtime_error("trailing metal-atmosphere identity data");
  }

  void hydrogen_atmosphere_interval(const std::string& role,const fs::path& path,unsigned depth=0) {
    if(depth>8)throw std::runtime_error("excessive atmosphere identity nesting");
    std::ifstream in(path);std::string label,name;unsigned version{};
    const auto expect=[&](const char* wanted) {
      if(!(in>>label) || label!=wanted)throw std::runtime_error("invalid hydrogen-atmosphere identity field");
    };
    const auto filename=[&](const char* field) {
      expect(field);if(!(in>>std::quoted(name)) || name.empty())throw std::runtime_error("missing atmosphere identity file");
      return path.parent_path()/name;
    };
    expect("EMBER_HYDROGEN_ATMOSPHERE_INTERVAL");
    if(!(in>>version) || (version!=1 && version!=2))throw std::runtime_error("invalid hydrogen-atmosphere identity version");
    number(role+".version",version);
    if(version==2) {
      const auto lower=filename("lower_interval"),chain=filename("lower_metal_chain");
      expect("lower_reference_Z");number(role+".lower_reference_Z",read_representable_double(in));
      hydrogen_atmosphere_interval(role+".lower",lower,depth+1);
      metal_atmosphere_chain(role+".lower_chain",chain);
    }
    const auto reference=filename("reference"),chain=filename("chain");
    file(role+".reference",reference);metal_atmosphere_chain(role+".chain",chain);
    expect("reference_Z");number(role+".reference_Z",read_representable_double(in));
    expect("hydrogen");number(role+".hydrogen_low",read_representable_double(in));
    number(role+".hydrogen_high",read_representable_double(in));
    if(in>>label)throw std::runtime_error("trailing hydrogen-atmosphere identity data");
  }

  void hydrogen_envelope(const std::string& role,const fs::path& path) {
    const auto s=HydrogenEnvelopeAtmosphere::read(path);
    number(role+".version",s.mixed_helium.empty()?1:2);
    file(role+".trace",s.trace);file(role+".low_gravity",s.low_gravity);
    file(role+".middle_gravity",s.middle_gravity);file(role+".high_gravity",s.high_gravity);
    number(role+".maximum_helium3",s.maximum_helium3);
    number(role+".maximum_helium",s.maximum_helium);
    if(!s.mixed_helium.empty()) {
      file(role+".mixed_helium",s.mixed_helium);
      number(role+".mixed_maximum_helium3",s.mixed_maximum_helium3);
      number(role+".mixed_maximum_metals",s.mixed_maximum_metals);
      number(role+".mixed_helium_join.low",s.mixed_helium_join[0]);
      number(role+".mixed_helium_join.high",s.mixed_helium_join[1]);
      number(role+".mixed_metal_join.low",s.mixed_metal_join[0]);
      number(role+".mixed_metal_join.high",s.mixed_metal_join[1]);
    }
    for(const auto& [name,bounds]:std::map<std::string,std::array<double,2>>{
        {"gravity_low",s.gravity_low},{"gravity_high",s.gravity_high},
        {"trace_helium_join",s.trace_helium_join},{"composition_helium_join",s.composition_helium_join},
        {"metal_join",s.metal_join},{"pure_metal_join",s.pure_metal_join}}) {
      number(role+"."+name+".low",bounds[0]);number(role+"."+name+".high",bounds[1]);
    }
  }

  void family(const std::string& role,const fs::path& path,bool eos) {
    std::ifstream in(path);std::string magic,label,name;int version{};std::size_t count=1;
    in>>magic>>version;
    if(!in)throw std::runtime_error("missing runtime family: "+role);
    values[role+".format"]=magic+" "+std::to_string(version);
    if(eos && magic=="EMBER_VARIABLE_METAL_HELMHOLTZ_BINARY" && (version==1 || version==2)) {
      file(role+".archive",path);return;
    }
    if(eos) {
      if(magic!="EMBER_VARIABLE_METAL_HELMHOLTZ" || (version!=1 && version!=2))
        throw std::runtime_error("invalid EOS identity format");
      for(const auto* axis:{"metals","hydrogen_share","helium3_share"}) {
        std::size_t n{};in>>label>>n;
        if(!in || label!=axis || n<2 || n>100)throw std::runtime_error("invalid EOS identity axis");
        count*=n;number(role+"."+axis+".size",static_cast<double>(n));
        for(std::size_t i=0;i<n;++i)
          number(role+"."+axis+"."+std::to_string(i),read_representable_double(in));
      }
    }else {
      in>>count>>label>>name;
      if(!in || magic!="EMBER_OPACITY_MIXTURE" || version!=1 || count<2 || count>100
          || (label!="logR" && label!="logRho"))
        throw std::runtime_error("invalid opacity identity family");
      values[role+".density_axis"]=label;
      values[role+".source"]=name;
      number(role+".size",static_cast<double>(count));
    }
    for(std::size_t i=0;i<count;++i) {
      const auto plane=role+".plane."+std::to_string(i);
      if(!eos)number(plane+".metallicity",read_representable_double(in));
      in>>std::quoted(name);
      if(!in || name.empty())throw std::runtime_error("missing family identity source");
      file(plane,path.parent_path()/name);
    }
    if(in>>name)throw std::runtime_error("trailing runtime family data");
  }
};
} // namespace ember::driver
