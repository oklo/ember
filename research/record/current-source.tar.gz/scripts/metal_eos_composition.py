"""GS98 element numbers for the baryonic FreeEOS source family.

Uses exactly the atmosphere's fixed GS98 element pattern and representative
integer masses. FreeEOS has no potassium entry; that trace omission is
recorded explicitly, rather than folding all metals into helium.
"""
import hashlib
import json
import math
from pathlib import Path
from generate_nongrey_grid import composition
from stellar_composition import interior_composition

ROOT=Path(__file__).resolve().parents[1]
ELEMENTS=['H','He','C','N','O','Ne','Na','Mg','Al','Si','P','S','Cl','Ar','Ca','Ti','Cr','Mn','Fe','Ni']


def mixture(hydrogen,helium3,*,metallicity=None):
    if metallicity is not None:
        return variable_mixture(hydrogen,helium3,metallicity)
    if not math.isfinite(hydrogen+helium3) or hydrogen<0 or helium3<0:
        raise ValueError('invalid baryonic composition')
    carried=interior_composition(hydrogen)
    carried[1]=helium3;carried[2]-=helium3
    if min(carried)<0:raise ValueError('invalid baryonic composition')
    # FreeEOS takes absolute element numbers per source gram and supports
    # genuinely zero hydrogen. Its input must not inherit the atmosphere
    # source's N(element)/N(H) normalization singularity. Keep the positive-H
    # path byte-identical to the archived families.
    reference_hydrogen = hydrogen if hydrogen>0 else .7
    abundance,_=composition(reference_hydrogen,helium3 if hydrogen>0 else 0,carried[3:])
    path=ROOT/'data/atmosphere/sources/synple-elements.json'
    elements=json.loads(path.read_text())
    index={s.lower():i for i,s in enumerate(elements['symbol'])}
    number=[reference_hydrogen*abundance[index[s.lower()]] for s in ELEMENTS]
    if hydrogen==0:
        number[0]=0.
        number[1]=helium3/3+carried[2]/4
    # Convert to a normalized atomic source gram, then convert every source
    # result back to the conserved baryonic gram. Helium uses source He4.
    weights=[elements['mass'][index[s.lower()]] for s in ELEMENTS]
    weights[0]=1.00782503;weights[1]=4.00260325
    scale=sum(n*w for n,w in zip(number,weights,strict=True))
    eps=[n/scale for n in number]
    k=index['k']
    return {'composition_basis':'baryon_mass','metal_mixture':'GS98',
            'hydrogen':hydrogen,'helium3':helium3,'composition':carried,
            'elements':ELEMENTS,'eps':eps,'source_mass_scale':scale,
            'potassium_number_per_baryon_mass':reference_hydrogen*abundance[k],
            'potassium_baryonic_mass_fraction':reference_hydrogen*abundance[k]*round(elements['mass'][k]),
            'element_metadata_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'metal_request_sha256':hashlib.sha256((ROOT/'data/opacity/sources/tops_gs98_x070_z020.request.json').read_bytes()).hexdigest(),
            'approximation':'Shared atmosphere GS98 element inventory; FreeEOS omits potassium; representative metal isotopes; source He4 electronic physics and analytic helium isotope entropy; inert carried metal slots retain their existing labels'}


def variable_mixture(hydrogen,helium3,metallicity):
    """Absolute element counts for a GS98 mixture with variable metal mass.

    No division by hydrogen or atmospheric abundance floors. This supports
    true zero-H, zero-metal and zero-He source compositions. It does not
    supply interpolation or authorize a changed stellar material lookup.
    """
    if (not all(math.isfinite(v) and v>=0 for v in (hydrogen,helium3,metallicity))
            or math.fsum((hydrogen,helium3,metallicity))>1):
        raise ValueError('invalid baryonic composition')
    helium4=1-math.fsum((hydrogen,helium3,metallicity))
    if helium4<0:raise ValueError('negative helium-4 fraction')
    carried=interior_composition(hydrogen)
    carried[1]=helium3;carried[2]=helium4
    original=sum(carried[3:])
    carried[3:]=[v*metallicity/original for v in carried[3:]]
    path=ROOT/'data/atmosphere/sources/synple-elements.json'
    elements=json.loads(path.read_text());index={s.lower():i for i,s in enumerate(elements['symbol'])}
    request=ROOT/'data/opacity/sources/tops_gs98_x070_z020.request.json'
    tokens=json.loads(request.read_text())['mixture'].split()[4:]
    pattern={tokens[i+1].lower():float(tokens[i]) for i in range(0,len(tokens),2)}
    total=sum(pattern.values())
    number=[hydrogen,helium3/3+helium4/4]
    number.extend(metallicity*pattern.get(s.lower(),0.)/total/round(elements['mass'][index[s.lower()]])
                  for s in ELEMENTS[2:])
    weights=[elements['mass'][index[s.lower()]] for s in ELEMENTS]
    weights[0]=1.00782503;weights[1]=4.00260325
    scale=sum(n*w for n,w in zip(number,weights,strict=True))
    if scale<=0:raise ValueError('empty source composition')
    potassium=metallicity*pattern.get('k',0.)/total
    return {'composition_basis':'baryon_mass','metal_mixture':'GS98',
            'hydrogen':hydrogen,'helium3':helium3,'metallicity':metallicity,'composition':carried,
            'elements':ELEMENTS,'eps':[n/scale for n in number],'source_mass_scale':scale,
            'potassium_number_per_baryon_mass':potassium/round(elements['mass'][index['k']]),
            'potassium_baryonic_mass_fraction':potassium,
            'element_metadata_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'metal_request_sha256':hashlib.sha256(request.read_bytes()).hexdigest(),
            'approximation':'Variable GS98 metal mass; FreeEOS omits potassium; representative metal isotopes; source He4 electronic physics and analytic helium isotope entropy; inert carried metal slots are material labels'}
